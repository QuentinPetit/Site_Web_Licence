# Leap-Motion-JS-API-for-Website-Navigation
Leap motion is a sensor device that supports hand and finger motions as input. It is analogous to a mouse but requiring no physical hand contact or touching. Our team has developed an API for leap motion that can be used to navigate websites by hand gestures conveniently.

For more details, please see the PDF report.
